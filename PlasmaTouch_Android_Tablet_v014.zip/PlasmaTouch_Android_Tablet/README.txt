PLASMATOUCH CAD/CAM — ANDROID TABLET EDITION v0.14

MAIN FILE
  index.html

DEVICE TARGET
  Samsung Galaxy Tab S7 FE (Android tablet)
  Dark industrial touchscreen layout; dimensions in inches.

DRAWING
  LINE: Select Line. Tap the start point, then tap the endpoint. You can also drag from the start point. The line appears before the dimension dialog opens. Enter exact angle and length, then tap Draw.
  CIRCLE: Select Circle. Tap the center, then tap the edge. You can also drag from center to edge. The circle appears before the radius dialog opens. Enter exact radius, then tap Draw.
  RECTANGLE: Drag corner to corner.
  POLYLINE: Tap vertices; double-tap to finish.

TOOLS
  Select/move, line, rectangle, circle, arc, polyline, undo/redo, delete,
  grid, snap, endpoint/midpoint/center snaps, zoom/pan, layers, properties,
  stock/job settings, command input, project save/open, DXF import/export,
  SVG export.

OFFLINE
  The app is a self-contained HTML file and uses no external libraries or
  network services. Save projects as .ptcad files. DXF export creates a
  standard ASCII DXF file for supported entities.

APKCREATOR
  If packaging in APKCreator, use its Local File option and choose index.html
  as the Main Page / Start Page. Do not point it at a folder or at README.txt.

IMPORTANT
  This is an offline CAD drawing and file-preparation app. It does NOT connect
  to, control, or send motion commands to the PlasmaCAM DHC2 controller.
